import { useState } from 'react';
import { useStore } from '../store/useStore';
import CustomerList from '../components/CustomerList/CustomerList';
import CustomerFormModal from '../components/CustomerForm/CustomerFormModal';
import { UserPlus } from 'lucide-react';

export default function CustomersPage() {
  const [showModal, setShowModal] = useState(false);
  const { customers } = useStore();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink-900">Customers</h1>
          <p className="text-sm text-ink-400 mt-0.5">{customers.length} registered customer{customers.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary">
          <UserPlus size={16} /> Add Customer
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Customers', value: customers.length, color: 'bg-ink-800 text-white' },
          { label: 'With Company', value: customers.filter(c => c.company).length, color: 'bg-accent-500 text-ink-900' },
          { label: 'Added This Month', value: customers.filter(c => new Date(c.createdAt).getMonth() === new Date().getMonth()).length, color: 'bg-sage-500 text-white' },
        ].map(stat => (
          <div key={stat.label} className={`rounded-xl p-4 ${stat.color}`}>
            <p className="text-3xl font-display font-bold">{stat.value}</p>
            <p className="text-xs font-semibold opacity-70 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <CustomerList />
      <CustomerFormModal open={showModal} onClose={() => setShowModal(false)} />
    </div>
  );
}
