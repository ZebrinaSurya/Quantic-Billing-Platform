import { useStore } from '../store/useStore';
import InvoiceForm from '../components/InvoiceForm/InvoiceForm';
import InvoiceList from '../components/InvoiceList/InvoiceList';
import { ArrowLeft, DollarSign, Clock, CheckCircle } from 'lucide-react';

export default function InvoicesPage() {
  const { invoices, selectedCustomerId, customers, setCurrentPage, setSelectedCustomerId } = useStore();

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);
  const filtered = selectedCustomerId ? invoices.filter(inv => inv.customerId === selectedCustomerId) : invoices;
  const paid = filtered.filter(i => i.status === 'paid').length;
  const unpaid = filtered.filter(i => i.status === 'unpaid').length;
  const total = filtered.reduce((acc, i) => acc + i.grandTotal, 0);

  const handleBack = () => { setCurrentPage('customers'); setSelectedCustomerId(null); };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <button onClick={handleBack} className="flex items-center gap-1.5 text-xs font-semibold text-ink-400 hover:text-ink-700 transition-colors mb-2">
            <ArrowLeft size={13} /> Back to Customers
          </button>
          <h1 className="font-display text-2xl font-bold text-ink-900">Invoices</h1>
          {selectedCustomer && (
            <p className="text-sm text-ink-400 mt-0.5">
              Showing invoices for <span className="font-semibold text-ink-600">{selectedCustomer.name}</span>
              {selectedCustomer.company && <span className="text-ink-400"> · {selectedCustomer.company}</span>}
            </p>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: DollarSign, label: 'Total Revenue', value: `$${total.toFixed(2)}`, color: 'bg-ink-800 text-white' },
          { icon: CheckCircle, label: 'Paid', value: paid, color: 'bg-sage-500 text-white' },
          { icon: Clock, label: 'Unpaid', value: unpaid, color: 'bg-accent-500 text-ink-900' },
        ].map(stat => (
          <div key={stat.label} className={`rounded-xl p-4 flex items-start gap-3 ${stat.color}`}>
            <stat.icon size={20} className="opacity-60 mt-0.5 shrink-0" />
            <div>
              <p className="text-2xl font-display font-bold">{stat.value}</p>
              <p className="text-xs font-semibold opacity-70 mt-0.5">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Form + List */}
      <InvoiceForm />
      <InvoiceList customerId={selectedCustomerId} />
    </div>
  );
}
