import { clsx } from '../../lib/cn'
import { Check } from 'lucide-react';

interface Step { label: string; }

interface Props {
  steps: Step[];
  current: number;
}

export default function StepIndicator({ steps, current }: Props) {
  return (
    <div className="flex items-center gap-0 px-6 py-5 border-b border-ink-100">
      {steps.map((step, i) => (
        <div key={i} className="flex items-center flex-1 last:flex-none">
          <div className="flex items-center gap-2.5">
            <div className={clsx(
              'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 shrink-0',
              i < current ? 'bg-sage-500 text-white' :
              i === current ? 'bg-ink-800 text-white ring-4 ring-ink-100' :
              'bg-ink-100 text-ink-400'
            )}>
              {i < current ? <Check size={14} /> : i + 1}
            </div>
            <span className={clsx(
              'text-sm font-semibold transition-colors',
              i === current ? 'text-ink-800' : i < current ? 'text-sage-600' : 'text-ink-400'
            )}>{step.label}</span>
          </div>
          {i < steps.length - 1 && (
            <div className={clsx(
              'h-px flex-1 mx-4 step-connector',
              i < current ? 'bg-sage-300' : 'bg-ink-100'
            )} />
          )}
        </div>
      ))}
    </div>
  );
}
