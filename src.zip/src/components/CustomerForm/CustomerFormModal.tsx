import { useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { customerSchema } from '../../lib/schemas';
import Modal from '../UI/Modal';
import StepIndicator from '../UI/StepIndicator';
import PersonalInfoStep from './PersonalInfoStep';
import AddressStep from './AddressStep';
import ReviewStep from './ReviewStep';
import type { CustomerFormData } from '../../lib/schemas';
import { emailExists, generateId } from '../../lib/db';
import { useStore } from '../../store/useStore';
import { ChevronLeft, ChevronRight, Save, Loader } from 'lucide-react';

const fullSchema = customerSchema;

const STEPS = [
  { label: 'Personal Info' },
  { label: 'Address Info' },
  { label: 'Review' },
];


interface Props { open: boolean; onClose: () => void; }

export default function CustomerFormModal({ open, onClose }: Props) {
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [emailError, setEmailError] = useState('');
  const addCustomer = useStore(s => s.addCustomer);

  const methods = useForm<CustomerFormData>({
    resolver: zodResolver(fullSchema),
    defaultValues: {
      name: '', email: '', phone: '', company: '',
      sameAsShipping: false,
      billingAddress: { street: '', city: '', state: '', zip: '', country: '' },
      shippingAddress: { street: '', city: '', state: '', zip: '', country: '' },
    },
    mode: 'onChange',
  });

  const handleNext = async () => {
    setEmailError('');
    const fields = getStepFields(step);
    const valid = await methods.trigger(fields as any);
    if (!valid) return;

    // Async email check on step 0
    if (step === 0) {
      const email = methods.getValues('email');
      if (email) {
        const exists = await emailExists(email);
        if (exists) {
          setEmailError('A customer with this email already exists.');
          methods.setError('email', { message: 'A customer with this email already exists.' });
          return;
        }
      }
    }

    // Copy billing to shipping if toggled
    if (step === 1) {
      const same = methods.getValues('sameAsShipping');
      if (same) {
        const billing = methods.getValues('billingAddress');
        methods.setValue('shippingAddress', { ...billing });
      }
    }

    setStep(s => s + 1);
  };

  const handleBack = () => { setStep(s => s - 1); setEmailError(''); };

  const handleSubmit = async () => {
    setSaving(true);
    try {
      const data = methods.getValues();
      const shipping = data.sameAsShipping ? { ...data.billingAddress } : data.shippingAddress;
      await addCustomer({
        id: generateId(),
        name: data.name,
        email: data.email,
        phone: data.phone,
        company: data.company,
        billingAddress: data.billingAddress,
        shippingAddress: shipping,
        createdAt: new Date().toISOString(),
      });
      methods.reset();
      setStep(0);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => { methods.reset(); setStep(0); setEmailError(''); onClose(); };

  return (
    <Modal open={open} onClose={handleClose} title="Add New Customer" size="lg">
      <FormProvider {...methods}>
        <StepIndicator steps={STEPS} current={step} />
        <div className="min-h-[340px]">
          {step === 0 && <PersonalInfoStep />}
          {step === 1 && <AddressStep />}
          {step === 2 && <ReviewStep />}
        </div>
        {emailError && (
          <p className="px-6 pb-2 text-red-500 text-sm font-medium">{emailError}</p>
        )}
        <div className="flex items-center justify-between px-6 py-4 border-t border-ink-100 bg-ink-50/50 rounded-b-2xl">
          <button type="button" onClick={handleBack} disabled={step === 0} className="btn-secondary disabled:opacity-30">
            <ChevronLeft size={16} /> Back
          </button>
          <div className="flex gap-2">
            {step < 2 ? (
              <button type="button" onClick={handleNext} className="btn-primary">
                Next <ChevronRight size={16} />
              </button>
            ) : (
              <button type="button" onClick={handleSubmit} disabled={saving} className="btn-accent">
                {saving ? <><Loader size={15} className="animate-spin" /> Saving…</> : <><Save size={15} /> Save Customer</>}
              </button>
            )}
          </div>
        </div>
      </FormProvider>
    </Modal>
  );
}

function getStepFields(step: number): string[] {
  if (step === 0) return ['name', 'email', 'phone', 'company'];
  if (step === 1) return ['billingAddress', 'shippingAddress'];
  return [];
}
