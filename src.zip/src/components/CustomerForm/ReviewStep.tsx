import React from 'react';
import { useFormContext } from 'react-hook-form';
import type { CustomerFormData } from '../../lib/schemas';
import { User, Mail, Phone, Building, MapPin } from 'lucide-react';

function Info({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value?: string }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-3">
      <Icon size={15} className="text-ink-400 mt-0.5 shrink-0" />
      <div>
        <p className="text-xs text-ink-400 font-medium">{label}</p>
        <p className="text-sm text-ink-800 font-medium">{value}</p>
      </div>
    </div>
  );
}

function AddressSummary({ address, title }: { address: CustomerFormData['billingAddress']; title: string }) {
  return (
    <div className="bg-ink-50 rounded-lg p-4">
      <p className="text-xs font-bold uppercase tracking-wider text-ink-500 mb-2 flex items-center gap-1.5">
        <MapPin size={12} /> {title}
      </p>
      <p className="text-sm text-ink-700">
        {address.street}<br />
        {address.city}, {address.state} {address.zip}<br />
        {address.country}
      </p>
    </div>
  );
}

export default function ReviewStep() {
  const { getValues } = useFormContext<CustomerFormData>();
  const data = getValues();

  return (
    <div className="p-6 space-y-6 animate-slide-up">
      <div>
        <h4 className="font-semibold text-sm text-ink-700 mb-3 pb-2 border-b border-ink-100">Personal Information</h4>
        <div className="grid grid-cols-2 gap-4">
          <Info icon={User} label="Full Name" value={data.name} />
          <Info icon={Mail} label="Email" value={data.email} />
          <Info icon={Phone} label="Phone" value={data.phone} />
          <Info icon={Building} label="Company" value={data.company} />
        </div>
      </div>
      <div>
        <h4 className="font-semibold text-sm text-ink-700 mb-3 pb-2 border-b border-ink-100">Address Information</h4>
        <div className="grid grid-cols-2 gap-4">
          <AddressSummary address={data.billingAddress} title="Billing Address" />
          <AddressSummary address={data.shippingAddress} title="Shipping Address" />
        </div>
      </div>

      <div className="bg-sage-50 border border-sage-200 rounded-lg p-3.5">
        <p className="text-xs text-sage-700 font-medium">✅ Review the information above before saving. Click "Save Customer" to confirm.</p>
      </div>
    </div>
  );
}
