import { useFormContext, useWatch } from 'react-hook-form';
import { useEffect } from 'react';
import type { CustomerFormData } from '../../lib/schemas';

function AddressBlock({ prefix, label }: { prefix: 'billingAddress' | 'shippingAddress'; label: string }) {
  const { register, formState: { errors } } = useFormContext<CustomerFormData>();
  const e = errors[prefix];

  return (
    <div>
      <h4 className="font-semibold text-sm text-ink-700 mb-3 pb-2 border-b border-ink-100">{label}</h4>
      <div className="space-y-3">
        <div>
          <label className="label">Street Address *</label>
          <input {...register(`${prefix}.street`)} className="input-field" placeholder="123 Main St" />
          {e?.street && <p className="error-text">{e.street.message}</p>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">City *</label>
            <input {...register(`${prefix}.city`)} className="input-field" placeholder="New York" />
            {e?.city && <p className="error-text">{e.city.message}</p>}
          </div>
          <div>
            <label className="label">State / Province *</label>
            <input {...register(`${prefix}.state`)} className="input-field" placeholder="NY" />
            {e?.state && <p className="error-text">{e.state.message}</p>}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">ZIP / Postal Code *</label>
            <input {...register(`${prefix}.zip`)} className="input-field" placeholder="10001" />
            {e?.zip && <p className="error-text">{e.zip.message}</p>}
          </div>
          <div>
            <label className="label">Country *</label>
            <input {...register(`${prefix}.country`)} className="input-field" placeholder="United States" />
            {e?.country && <p className="error-text">{e.country.message}</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AddressStep() {
  const { register, setValue, getValues, formState: { errors } } = useFormContext<CustomerFormData>();
  const sameAsShipping = useWatch({ name: 'sameAsShipping' });

  useEffect(() => {
    if (sameAsShipping) {
      const billing = getValues('billingAddress');
      setValue('shippingAddress', { ...billing }, { shouldValidate: false });
    }
  }, [sameAsShipping, getValues, setValue]);

  return (
    <div className="space-y-6 p-6 animate-slide-up">
      <AddressBlock prefix="billingAddress" label="Billing Address" />

      <div className="flex items-center gap-3 py-2">
        <input
          type="checkbox"
          id="sameAsShipping"
          {...register('sameAsShipping')}
          className="w-4 h-4 accent-ink-800 cursor-pointer"
        />
        <label htmlFor="sameAsShipping" className="text-sm font-medium text-ink-600 cursor-pointer">
          Shipping address is same as billing
        </label>
      </div>

      {!sameAsShipping && (
        <AddressBlock prefix="shippingAddress" label="Shipping Address" />
      )}
    </div>
  );
}
