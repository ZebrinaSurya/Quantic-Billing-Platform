import { useFormContext } from 'react-hook-form';
import type { CustomerFormData } from '../../lib/schemas';

export default function PersonalInfoStep() {
  const { register, formState: { errors } } = useFormContext<CustomerFormData>();

  return (
    <div className="space-y-5 p-6 animate-slide-up">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <label className="label">Full Name *</label>
          <input {...register('name')} className="input-field" placeholder="Jane Smith" />
          {errors.name && <p className="error-text">{errors.name.message}</p>}
        </div>

        <div>
          <label className="label">Email Address *</label>
          <input {...register('email')} type="email" className="input-field" placeholder="jane@company.com" />
          {errors.email && <p className="error-text">{errors.email.message}</p>}
        </div>

        <div>
          <label className="label">Phone <span className="normal-case font-normal text-ink-400">(optional if email given)</span></label>
          <input {...register('phone')} type="tel" className="input-field" placeholder="+1 (555) 000-0000" />
          {errors.phone && <p className="error-text">{errors.phone.message}</p>}
        </div>

        <div className="col-span-2">
          <label className="label">Company <span className="normal-case font-normal text-ink-400">(optional)</span></label>
          <input {...register('company')} className="input-field" placeholder="Acme Corporation" />
        </div>
      </div>

      <div className="bg-accent-50 border border-accent-200 rounded-lg p-3.5">
        <p className="text-xs text-accent-700 font-medium">
          📧 Email will be used for async duplicate check. Phone is only required if no email is provided.
        </p>
      </div>
    </div>
  );
}
