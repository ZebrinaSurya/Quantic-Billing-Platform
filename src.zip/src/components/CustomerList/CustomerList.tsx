import { useStore } from '../../store/useStore';
import { useMemo } from 'react';
import { Search, ArrowUpDown, Trash2, ChevronLeft, ChevronRight, User, Receipt } from 'lucide-react';
import { clsx } from '../../lib/cn'
import type { Customer } from '../../types';

const PAGE_SIZE = 8;

export default function CustomerList() {
  const {
    customers, customersLoading, deleteCustomer,
    customerSearch, setCustomerSearch,
    customerSortField, setCustomerSortField,
    customerSortDir, setCustomerSortDir,
    customerPage, setCustomerPage,
    setCurrentPage, setSelectedCustomerId,
  } = useStore();

  const filtered = useMemo(() => {
    let list = [...customers];
    if (customerSearch) {
      const q = customerSearch.toLowerCase();
      list = list.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        (c.company || '').toLowerCase().includes(q)
      );
    }
    list.sort((a, b) => {
      const va = a[customerSortField] ?? '';
      const vb = b[customerSortField] ?? '';
      return customerSortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
    });
    return list;
  }, [customers, customerSearch, customerSortField, customerSortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((customerPage - 1) * PAGE_SIZE, customerPage * PAGE_SIZE);

  const toggleSort = (field: typeof customerSortField) => {
    if (customerSortField === field) setCustomerSortDir(customerSortDir === 'asc' ? 'desc' : 'asc');
    else { setCustomerSortField(field); setCustomerSortDir('asc'); }
  };

  const handleViewInvoices = (c: Customer) => {
    setSelectedCustomerId(c.id);
    setCurrentPage('invoices');
  };

  const SortBtn = ({ field, label }: { field: typeof customerSortField; label: string }) => (
    <button onClick={() => toggleSort(field)} className="flex items-center gap-1 hover:text-ink-900 transition-colors">
      {label}
      <ArrowUpDown size={13} className={clsx(customerSortField === field ? 'text-accent-600' : 'text-ink-300')} />
    </button>
  );

  return (
    <div className="card animate-slide-up">
      {/* Search bar */}
      <div className="p-4 border-b border-ink-100 flex items-center gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={customerSearch}
            onChange={e => setCustomerSearch(e.target.value)}
            placeholder="Search customers by name, email, or company…"
            className="input-field pl-9"
          />
        </div>
        <span className="text-xs text-ink-400 font-medium whitespace-nowrap">{filtered.length} customer{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100 bg-ink-50/60">
              <th className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400"><SortBtn field="name" label="Name" /></th>
              <th className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400"><SortBtn field="email" label="Email" /></th>
              <th className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Company</th>
              <th className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Phone</th>
              <th className="text-left px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400"><SortBtn field="createdAt" label="Added" /></th>
              <th className="text-right px-4 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Actions</th>
            </tr>
          </thead>
          <tbody>
            {customersLoading ? (
              <tr><td colSpan={6} className="text-center py-12 text-ink-400">Loading…</td></tr>
            ) : paginated.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-16">
                  <User size={36} className="mx-auto text-ink-200 mb-3" />
                  <p className="text-ink-400 font-medium">No customers found</p>
                  <p className="text-ink-300 text-xs mt-1">
                    {customerSearch ? 'Try a different search term' : 'Add your first customer using the button above'}
                  </p>
                </td>
              </tr>
            ) : paginated.map((c, i) => (
              <tr key={c.id} className={clsx('border-b border-ink-50 hover:bg-ink-50/50 transition-colors', i % 2 === 0 ? '' : 'bg-ink-50/20')}>
                <td className="px-4 py-3.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 bg-ink-800 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-semibold text-ink-800">{c.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3.5 text-ink-600 font-mono text-xs">{c.email}</td>
                <td className="px-4 py-3.5 text-ink-600">{c.company || <span className="text-ink-300">—</span>}</td>
                <td className="px-4 py-3.5 text-ink-600">{c.phone || <span className="text-ink-300">—</span>}</td>
                <td className="px-4 py-3.5 text-ink-400 text-xs">{new Date(c.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3.5">
                  <div className="flex items-center justify-end gap-1.5">
                    <button onClick={() => handleViewInvoices(c)} title="View invoices"
                      className="p-1.5 hover:bg-accent-100 text-ink-400 hover:text-accent-700 rounded-lg transition-colors">
                      <Receipt size={15} />
                    </button>
                    <button onClick={() => deleteCustomer(c.id)} title="Delete customer"
                      className="p-1.5 hover:bg-red-50 text-ink-400 hover:text-red-500 rounded-lg transition-colors">
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-ink-100">
          <p className="text-xs text-ink-400">
            Page {customerPage} of {totalPages} · {filtered.length} total
          </p>
          <div className="flex gap-1">
            <button onClick={() => setCustomerPage(customerPage - 1)} disabled={customerPage === 1} className="btn-secondary py-1.5 px-2.5 text-xs disabled:opacity-40">
              <ChevronLeft size={14} />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setCustomerPage(p)}
                className={clsx('py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors',
                  p === customerPage ? 'bg-ink-800 text-white' : 'hover:bg-ink-100 text-ink-600')}>
                {p}
              </button>
            ))}
            <button onClick={() => setCustomerPage(customerPage + 1)} disabled={customerPage === totalPages} className="btn-secondary py-1.5 px-2.5 text-xs disabled:opacity-40">
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
