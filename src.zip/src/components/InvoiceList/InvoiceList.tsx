import { useStore } from '../../store/useStore';
import { useMemo } from 'react';
import { Trash2, CheckCircle, Clock, FileText } from 'lucide-react';
import { clsx } from '../../lib/cn'
import type { Invoice } from '../../types';

interface Props {
  customerId?: string | null;
}

export default function InvoiceList({ customerId }: Props) {
  const { invoices, invoicesLoading, updateInvoiceStatus, deleteInvoice } = useStore();

  const filtered = useMemo(() => {
    if (customerId) return invoices.filter(inv => inv.customerId === customerId);
    return invoices;
  }, [invoices, customerId]);

  const fmt = (n: number) => `$${n.toFixed(2)}`;

  if (invoicesLoading) {
    return <div className="text-center py-12 text-ink-400">Loading invoices…</div>;
  }

  return (
    <div className="card animate-slide-up">
      <div className="px-5 py-4 border-b border-ink-100 flex items-center justify-between">
        <h3 className="font-display font-bold text-ink-900">Recent Invoices</h3>
        <span className="text-xs text-ink-400 font-medium">{filtered.length} invoice{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100 bg-ink-50/60">
              <th className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Invoice #</th>
              <th className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Customer</th>
              <th className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Date</th>
              <th className="text-left px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Due Date</th>
              <th className="text-right px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Total</th>
              <th className="text-center px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Status</th>
              <th className="text-right px-5 py-3 text-xs font-bold uppercase tracking-wider text-ink-400">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-14">
                  <FileText size={36} className="mx-auto text-ink-200 mb-3" />
                  <p className="text-ink-400 font-medium">No invoices yet</p>
                  <p className="text-ink-300 text-xs mt-1">Create an invoice using the form above</p>
                </td>
              </tr>
            ) : filtered.map((inv, i) => (
              <tr key={inv.id} className={clsx('border-b border-ink-50 hover:bg-ink-50/50 transition-colors', i % 2 === 0 ? '' : 'bg-ink-50/20')}>
                <td className="px-5 py-3.5">
                  <span className="font-mono text-xs bg-ink-100 text-ink-600 px-2 py-1 rounded-md">{inv.invoiceNumber}</span>
                </td>
                <td className="px-5 py-3.5 font-medium text-ink-800">{inv.customerName}</td>
                <td className="px-5 py-3.5 text-ink-600">{new Date(inv.date + 'T00:00:00').toLocaleDateString()}</td>
                <td className="px-5 py-3.5 text-ink-600">{new Date(inv.dueDate + 'T00:00:00').toLocaleDateString()}</td>
                <td className="px-5 py-3.5 text-right font-bold font-mono text-ink-800">{fmt(inv.grandTotal)}</td>
                <td className="px-5 py-3.5 text-center">
                  <button
                    onClick={() => updateInvoiceStatus(inv.id, inv.status === 'paid' ? 'unpaid' : 'paid')}
                    title="Click to toggle status"
                    className={clsx('transition-all hover:scale-105', inv.status === 'paid' ? 'badge-paid' : 'badge-unpaid')}
                  >
                    {inv.status === 'paid'
                      ? <><CheckCircle size={11} /> paid</>
                      : <><Clock size={11} /> unpaid</>
                    }
                  </button>
                </td>
                <td className="px-5 py-3.5">
                  <div className="flex items-center justify-end">
                    <button onClick={() => deleteInvoice(inv.id)} title="Delete invoice"
                      className="p-1.5 hover:bg-red-50 text-ink-300 hover:text-red-500 rounded-lg transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
