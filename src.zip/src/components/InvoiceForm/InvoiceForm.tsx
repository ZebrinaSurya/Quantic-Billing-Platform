import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { invoiceSchema } from '../../lib/schemas';
import type { InvoiceFormData } from '../../lib/schemas';
import { useStore } from '../../store/useStore';
import { generateId, generateInvoiceNumber } from '../../lib/db';
import { Plus, Trash2, Loader } from 'lucide-react';
import { useState, useMemo } from 'react';

const TAX_RATES = [0, 5, 10, 15, 18, 20];
const today = new Date().toISOString().split('T')[0];

export default function InvoiceForm() {
  const { customers, addInvoice, selectedCustomerId } = useStore();
  const [saving, setSaving] = useState(false);

  const { register, control, handleSubmit, watch, reset, formState: { errors } } = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      customerId: selectedCustomerId || '',
      date: today,
      dueDate: '',
      items: [{ id: generateId(), description: '', quantity: 1, price: 0, taxRate: 10 }],
    },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'items' });
  const items = watch('items');

  const { subtotal, totalTax, grandTotal } = useMemo(() => {
    let sub = 0, tax = 0;
    (items || []).forEach(item => {
      const lineTotal = (item.quantity || 0) * (item.price || 0);
      sub += lineTotal;
      tax += lineTotal * ((item.taxRate || 0) / 100);
    });
    return { subtotal: sub, totalTax: tax, grandTotal: sub + tax };
  }, [items]);

  const fmt = (n: number) => `$${n.toFixed(2)}`;

  const onSubmit = async (data: InvoiceFormData) => {
    setSaving(true);
    try {
      const customer = customers.find(c => c.id === data.customerId);
      const items = data.items.map(item => ({
        ...item,
        id: item.id || generateId(),
      }));
      let sub = 0, tax = 0;
      items.forEach(item => {
        const line = item.quantity * item.price;
        sub += line;
        tax += line * (item.taxRate / 100);
      });
      await addInvoice({
        id: generateId(),
        invoiceNumber: generateInvoiceNumber(),
        customerId: data.customerId,
        customerName: customer?.name || '',
        date: data.date,
        dueDate: data.dueDate,
        items,
        subtotal: sub,
        totalTax: tax,
        grandTotal: sub + tax,
        status: 'unpaid',
        createdAt: new Date().toISOString(),
      });
      reset({
        customerId: data.customerId,
        date: today,
        dueDate: '',
        items: [{ id: generateId(), description: '', quantity: 1, price: 0, taxRate: 10 }],
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card p-6 animate-slide-up">
      <h3 className="font-display text-base font-bold text-ink-900 mb-5">Create New Invoice</h3>

      {/* Customer */}
      <div className="mb-4">
        <label className="label">Customer *</label>
        <select {...register('customerId')} className="input-field">
          <option value="">Select a customer…</option>
          {customers.map(c => (
            <option key={c.id} value={c.id}>{c.company ? `${c.company} (${c.email})` : `${c.name} (${c.email})`}</option>
          ))}
        </select>
        {errors.customerId && <p className="error-text">{errors.customerId.message}</p>}
      </div>

      {/* Dates */}
      <div className="grid grid-cols-2 gap-4 mb-5">
        <div>
          <label className="label">Invoice Date *</label>
          <input type="date" {...register('date')} className="input-field" />
          {errors.date && <p className="error-text">{errors.date.message}</p>}
        </div>
        <div>
          <label className="label">Due Date *</label>
          <input type="date" {...register('dueDate')} className="input-field" />
          {errors.dueDate && <p className="error-text">{errors.dueDate.message}</p>}
        </div>
      </div>

      {/* Items */}
      <div className="mb-4">
        <p className="label mb-3">Items</p>
        <div className="space-y-2">
          <div className="grid grid-cols-12 gap-2 px-1">
            <p className="col-span-5 text-xs text-ink-400 font-semibold uppercase tracking-wider">Item Name *</p>
            <p className="col-span-2 text-xs text-ink-400 font-semibold uppercase tracking-wider">Qty *</p>
            <p className="col-span-2 text-xs text-ink-400 font-semibold uppercase tracking-wider">Price *</p>
            <p className="col-span-2 text-xs text-ink-400 font-semibold uppercase tracking-wider">Tax %</p>
            <p className="col-span-1"></p>
          </div>

          {fields.map((field, i) => (
            <div key={field.id} className="grid grid-cols-12 gap-2 items-start">
              <div className="col-span-5">
                <input {...register(`items.${i}.description`)} className="input-field" placeholder="Service or product name" />
                {errors.items?.[i]?.description && <p className="error-text">{errors.items[i]?.description?.message}</p>}
              </div>
              <div className="col-span-2">
                <input type="number" min={1} {...register(`items.${i}.quantity`, { valueAsNumber: true })} className="input-field" />
              </div>
              <div className="col-span-2">
                <input type="number" min={0} step="0.01" {...register(`items.${i}.price`, { valueAsNumber: true })} className="input-field" />
              </div>
              <div className="col-span-2">
                <select {...register(`items.${i}.taxRate`, { valueAsNumber: true })} className="input-field">
                  {TAX_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
                </select>
              </div>
              <div className="col-span-1 flex items-center justify-center pt-1">
                {fields.length > 1 && (
                  <button type="button" onClick={() => remove(i)} className="p-1.5 hover:bg-red-50 text-ink-300 hover:text-red-500 rounded-lg transition-colors">
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
        {errors.items && typeof errors.items.message === 'string' && (
          <p className="error-text mt-1">{errors.items.message}</p>
        )}
        <button type="button" onClick={() => append({ id: generateId(), description: '', quantity: 1, price: 0, taxRate: 10 })}
          className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-ink-500 hover:text-ink-800 transition-colors px-3 py-1.5 border border-dashed border-ink-200 rounded-lg hover:border-ink-400">
          <Plus size={13} /> Add Item
        </button>
      </div>

      {/* Totals */}
      <div className="grid grid-cols-2 gap-3 mb-5 bg-ink-50 rounded-xl p-4">
        <div>
          <p className="text-xs text-ink-500 font-medium mb-0.5">Subtotal:</p>
          <p className="text-sm font-bold text-ink-800 font-mono">{fmt(subtotal)}</p>
        </div>
        <div>
          <p className="text-xs text-ink-500 font-medium mb-0.5">Total Tax:</p>
          <p className="text-sm font-bold text-ink-800 font-mono">{fmt(totalTax)}</p>
        </div>
        <div className="col-span-2 border-t border-ink-200 pt-3">
          <p className="text-xs text-ink-500 font-medium mb-0.5">Grand Total:</p>
          <p className="text-xl font-bold text-ink-900 font-mono">{fmt(grandTotal)}</p>
        </div>
      </div>

      <div className="flex justify-end">
        <button type="submit" disabled={saving} className="btn-primary">
          {saving ? <><Loader size={15} className="animate-spin" /> Creating…</> : 'Create Invoice'}
        </button>
      </div>
    </form>
  );
}
