import { create } from 'zustand';
import type { Customer, Invoice, AppPage } from '../types';
import * as db from '../lib/db';

interface AppState {
  // Navigation
  currentPage: AppPage;
  setCurrentPage: (page: AppPage) => void;

  // Customers
  customers: Customer[];
  customersLoading: boolean;
  fetchCustomers: () => Promise<void>;
  addCustomer: (customer: Customer) => Promise<void>;
  deleteCustomer: (id: string) => Promise<void>;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;

  // Invoices
  invoices: Invoice[];
  invoicesLoading: boolean;
  fetchInvoices: () => Promise<void>;
  addInvoice: (invoice: Invoice) => Promise<void>;
  updateInvoiceStatus: (id: string, status: 'paid' | 'unpaid') => Promise<void>;
  deleteInvoice: (id: string) => Promise<void>;

  // UI
  showCustomerModal: boolean;
  setShowCustomerModal: (show: boolean) => void;

  // Filters
  customerSearch: string;
  setCustomerSearch: (q: string) => void;
  customerSortField: 'name' | 'email' | 'createdAt';
  setCustomerSortField: (f: 'name' | 'email' | 'createdAt') => void;
  customerSortDir: 'asc' | 'desc';
  setCustomerSortDir: (d: 'asc' | 'desc') => void;
  customerPage: number;
  setCustomerPage: (p: number) => void;
}

export const useStore = create<AppState>((set, get) => ({
  currentPage: 'customers',
  setCurrentPage: (page) => set({ currentPage: page }),

  customers: [],
  customersLoading: false,
  fetchCustomers: async () => {
    set({ customersLoading: true });
    const customers = await db.getAllCustomers();
    set({ customers, customersLoading: false });
  },
  addCustomer: async (customer) => {
    await db.saveCustomer(customer);
    await get().fetchCustomers();
  },
  deleteCustomer: async (id) => {
    await db.deleteCustomer(id);
    await get().fetchCustomers();
  },
  selectedCustomerId: null,
  setSelectedCustomerId: (id) => set({ selectedCustomerId: id }),

  invoices: [],
  invoicesLoading: false,
  fetchInvoices: async () => {
    set({ invoicesLoading: true });
    const invoices = await db.getAllInvoices();
    set({ invoices, invoicesLoading: false });
  },
  addInvoice: async (invoice) => {
    await db.saveInvoice(invoice);
    await get().fetchInvoices();
  },
  updateInvoiceStatus: async (id, status) => {
    await db.updateInvoiceStatus(id, status);
    await get().fetchInvoices();
  },
  deleteInvoice: async (id) => {
    await db.deleteInvoice(id);
    await get().fetchInvoices();
  },

  showCustomerModal: false,
  setShowCustomerModal: (show) => set({ showCustomerModal: show }),

  customerSearch: '',
  setCustomerSearch: (q) => set({ customerSearch: q, customerPage: 1 }),
  customerSortField: 'createdAt',
  setCustomerSortField: (f) => set({ customerSortField: f }),
  customerSortDir: 'desc',
  setCustomerSortDir: (d) => set({ customerSortDir: d }),
  customerPage: 1,
  setCustomerPage: (p) => set({ customerPage: p }),
}));
