import { useEffect } from 'react';
import { useStore } from './store/useStore';
import CustomersPage from './pages/CustomersPage';
import InvoicesPage from './pages/InvoicesPage';
import { Users, FileText, Zap } from 'lucide-react';
import { clsx } from './lib/cn'

export default function App() {
  const { currentPage, setCurrentPage, fetchCustomers, fetchInvoices } = useStore();

  useEffect(() => {
    fetchCustomers();
    fetchInvoices();
  }, []);

  const nav = [
    { id: 'customers' as const, label: 'Customers', icon: Users },
    { id: 'invoices' as const, label: 'Invoices', icon: FileText },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top navigation bar */}
      <header className="bg-white border-b border-ink-100 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-14">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 bg-ink-800 rounded-lg flex items-center justify-center">
              <Zap size={14} className="text-accent-400" fill="currentColor" />
            </div>
            <span className="font-display font-bold text-ink-900 text-lg tracking-tight">Quantic</span>
            <span className="text-ink-200 ml-1">|</span>
            <span className="text-xs font-semibold text-ink-400 ml-1">Billing Platform</span>
          </div>

          <nav className="flex items-center gap-1">
            {nav.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setCurrentPage(id)}
                className={clsx(
                  'flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-150',
                  currentPage === id
                    ? 'bg-ink-800 text-white'
                    : 'text-ink-500 hover:text-ink-800 hover:bg-ink-50'
                )}>
                <Icon size={15} />
                {label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-8">
        {currentPage === 'customers' && <CustomersPage />}
        {currentPage === 'invoices' && <InvoicesPage />}
      </main>

      {/* Footer */}
      <footer className="border-t border-ink-100 py-4">
        <div className="max-w-6xl mx-auto px-6">
          <p className="text-xs text-ink-300 text-center">Quantic Billing Platform · Data stored locally via IndexedDB</p>
        </div>
      </footer>
    </div>
  );
}
