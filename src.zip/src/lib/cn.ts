export function cn(...classes: (string | boolean | undefined | null | Record<string, boolean>)[]): string {
  return classes
    .flatMap(cls => {
      if (!cls) return [];
      if (typeof cls === 'string') return [cls];
      if (typeof cls === 'boolean') return [];
      if (typeof cls === 'object') {
        return Object.entries(cls).filter(([, v]) => v).map(([k]) => k);
      }
      return [];
    })
    .join(' ');
}
export const clsx = cn;