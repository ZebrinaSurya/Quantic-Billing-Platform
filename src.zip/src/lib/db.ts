import type { Customer, Invoice } from '../types';

const DB_NAME = 'quantic-billing';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('customers')) db.createObjectStore('customers', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('invoices')) db.createObjectStore('invoices', { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function getAll<T>(storeName: string): Promise<T[]> {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  }));
}

function putItem<T>(storeName: string, item: T): Promise<void> {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  }));
}

function deleteItem(storeName: string, id: string): Promise<void> {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  }));
}

function getItem<T>(storeName: string, id: string): Promise<T | null> {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(id);
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  }));
}

export async function getAllCustomers(): Promise<Customer[]> {
  const customers = await getAll<Customer>('customers');
  return customers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
export async function getCustomerById(id: string): Promise<Customer | null> { return getItem<Customer>('customers', id); }
export async function saveCustomer(customer: Customer): Promise<Customer> { await putItem('customers', customer); return customer; }
export async function deleteCustomer(id: string): Promise<void> { await deleteItem('customers', id); }
export async function emailExists(email: string, excludeId?: string): Promise<boolean> {
  const customers = await getAllCustomers();
  return customers.some(c => c.email.toLowerCase() === email.toLowerCase() && c.id !== excludeId);
}
export async function getAllInvoices(): Promise<Invoice[]> {
  const invoices = await getAll<Invoice>('invoices');
  return invoices.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
export async function getInvoicesByCustomer(customerId: string): Promise<Invoice[]> { return (await getAllInvoices()).filter(inv => inv.customerId === customerId); }
export async function saveInvoice(invoice: Invoice): Promise<Invoice> { await putItem('invoices', invoice); return invoice; }
export async function updateInvoiceStatus(id: string, status: 'paid' | 'unpaid'): Promise<void> {
  const inv = await getItem<Invoice>('invoices', id);
  if (inv) await putItem('invoices', { ...inv, status });
}
export async function deleteInvoice(id: string): Promise<void> { await deleteItem('invoices', id); }
export function generateId(): string { return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`; }
export function generateInvoiceNumber(): string { return `INV-${Math.floor(1000000 + Math.random() * 9000000)}`; }