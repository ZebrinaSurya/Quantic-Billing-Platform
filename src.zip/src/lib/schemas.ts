import { z } from 'zod';

const addressSchema = z.object({
  street: z.string().min(3, 'Street is required'),
  city: z.string().min(2, 'City is required'),
  state: z.string().min(2, 'State is required'),
  zip: z.string().regex(/^\d{4,10}$/, 'Enter a valid ZIP/postal code'),
  country: z.string().min(2, 'Country is required'),
});

const personalInfoBase = z.object({
  name: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().optional(),
  company: z.string().optional(),
});

export const personalInfoSchema = personalInfoBase.superRefine((data, ctx) => {
  if (!data.email && !data.phone) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Phone is required when email is not provided', path: ['phone'] });
  }
});

export const addressInfoSchema = z.object({
  billingAddress: addressSchema,
  shippingAddress: addressSchema,
  sameAsShipping: z.boolean().optional(),
});

export const customerSchema = personalInfoBase.merge(addressInfoSchema).superRefine((data, ctx) => {
  if (!data.email && !data.phone) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Phone is required when email is not provided', path: ['phone'] });
  }
});

export type CustomerFormData = z.infer<typeof customerSchema>;

export const invoiceItemSchema = z.object({
  id: z.string(),
  description: z.string().min(1, 'Item description is required'),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  price: z.number().min(0, 'Price must be 0 or more'),
  taxRate: z.number().min(0).max(100),
});

export const invoiceSchema = z.object({
  customerId: z.string().min(1, 'Please select a customer'),
  date: z.string().min(1, 'Invoice date is required'),
  dueDate: z.string().min(1, 'Due date is required'),
  items: z.array(invoiceItemSchema).min(1, 'Add at least one item'),
}).superRefine((data, ctx) => {
  if (data.dueDate && data.date && data.dueDate < data.date) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Due date must be after invoice date', path: ['dueDate'] });
  }
});

export type InvoiceFormData = z.infer<typeof invoiceSchema>;